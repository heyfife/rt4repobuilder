function just_testing() {
    alert("hi");
}
